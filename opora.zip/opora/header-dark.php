<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <meta http-equiv="x-ua-compatible" content="ie=edge" />
   <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/styles/index.css">
   <link crossorigin="anonymous" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap"
      rel="stylesheet" />

   <title>
      Опора России

   </title>
   <?php wp_head(); ?>
</head>

<body>

   <!-- -------------- Wrapper Page -------------- -->
   <div class="wrapper__page">

      <!-- -------------- Header -------------- -->
      <header class="header">
         <div class="_container">
            <div class="header__items">
               <div class="header-logo">
                  <a href="../src/template.html"><img src="<?php echo get_template_directory_uri();?>/assets/images/logo/logo-opora.svg" alt="Лого Опора России"></a>
               </div>
               <nav class="nav">
                  <ul class="nav__list">
                     <li class="link link-dark link-active"><a href="#">Об организации</a></li>
                     <li class="link link-dark"><a href="#">Дела</a></li>
                     <li class="link link-dark"><a href="../src/comitets.html">Комитеты</a></li>
                     <li class="link link-dark"><a href="#">Отдиления</a></li>
                     <li class="link link-dark"><a href="#">Вступить</a></li>
                  </ul>
               </nav>
               <div class="haeder__user-account"><a href="#">Личный кабинет</a></div>
            </div>
         </div>
      </header>
