<?php 
/*
   Template Name: Главная
*/
?>

<?php get_header(); ?>

      <main class="main">

         <!-- -------------- First screen -------------- -->
         <section class="section first-screen">
            <div class="_container">
               <div class="first-screen__wrapper">
                  <div class="first-screen__text">
                     <h1 class="first-screen__text__title"><?php the_title(); ?></h1>
                     <div class="first-screen__text__description">
                        <?php echo get_post_meta(get_the_ID(), 'descr', true) ?>
                     </div>
                     <a href="#" class="btn">Подробнее</a>
                  </div>
                  <div class="first-screen__img"></div>
               </div>
            </div>
         </section>

         <!-- -------------- News screen -------------- -->
         <section id="news" class="sections sections-news">
            <div class="_container">
               <div class="section__header">
                  <h2 class="section-title section-title__news">Новости, анонсы, события</h2>
                  <a href="#" class="more-news">Смотреть все новости</a>
               </div>



               <!--  -------------- Tabs  -------------- -->

               <div class="tabs">
                  <ul class="tabs__list">
                     <li class="tabs__item"><button class="tabs__btn tabs__btn--active"
                           data-tabs-path="udm">Удмуртия</button></li>
                     <li class="tabs__item"><button class="tabs__btn" data-tabs-path="anons">Анонсы</button></li>
                     <li class="tabs__item"><button class="tabs__btn" data-tabs-path="comitets-culture">Комитеты по
                           культуре
                           Предпринимательства</button></li>
                     <li class="tabs__item"><button class="tabs__btn" data-tabs-path="comitets">Комитеты по
                           самозанятым</button></li>

                  </ul>
                  <div class="tabs__content tabs__content--active" data-tabs-target="udm">
                     <div class="content">
                        <ul class="content__list">
                     
                               <li class="content__item">
                                       <a href="#" class="content__link">
                                          <img src="<?php echo get_the_post_thumbnail_url();?>" alt="img">
                                          <div class="date-event">25.05.2021</div>
                                       </a>
                                       <div class="info-contetn__element-event">
                                          <div class="category__element-event">Новости</div>
                                          <div class="title__element-event"><?php the_title(); ?></div>
                                          <div class="description__element-event"><?php the_content(); ?></div>
                                       </div>

                                       <a href="#" class="more__about-event">Смотреть полностью</a>
                                    </li>
                         
                        
                        
                        </ul>
                     </div>
                  </div>
                  <div class="tabs__content" data-tabs-target="anons">
                     <div class="content">
                        <ul class="content__list">
                           <li class="content__item">
                              <a href="#" class="content__link" style="">
                                 <div class="date-event">25.05.2021</div>
                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">eecececec</div>
                                 <div class="description__element-event">Можно предусмотреть краткое описание в
                                    нексолько
                                    строчек, чтоб было понятно о чём новость/анонс/событие</div>
                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png;">
                                 <div class="date-event">25.05.2021</div>
                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">eecececec</div>
                                 <div class="description__element-event">Можно предусмотреть краткое описание в
                                    нексолько
                                    строчек, чтоб было понятно о чём новость/анонс/событие</div>
                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png;">
                                 <div class="date-event">25.05.2021</div>
                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">eecececec</div>
                                 <div class="description__element-event">Можно предусмотреть краткое описание в
                                    нексолько
                                    строчек, чтоб было понятно о чём новость/анонс/событие</div>
                              </div>
                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="tabs__content" data-tabs-target="comitets-culture">
                     <div class="content">
                        <ul class="content__list">
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">
                                 <div class="date-event">25.05.2021</div>
                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>
                                 <div class="description__element-event">Можно предусмотреть краткое описание в
                                    нексолько
                                    строчек, чтоб было понятно о чём новость/анонс/событие</div>
                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">
                                 <div class="date-event">25.05.2021</div>
                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>
                                 <div class="description__element-event">Можно предусмотреть краткое описание в
                                    нексолько
                                    строчек, чтоб было понятно о чём новость/анонс/событие</div>
                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">
                                 <div class="date-event">25.05.2021</div>
                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>
                                 <div class="description__element-event">Можно предусмотреть краткое описание в
                                    нексолько
                                    строчек, чтоб было понятно о чём новость/анонс/событие</div>
                              </div>
                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="tabs__content" data-tabs-target="comitets">
                     <div class="content">
                        <ul class="content__list">
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">
                                 <div class="date-event">25.05.2021</div>
                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>
                                 <div class="description__element-event">Можно предусмотреть краткое описание в
                                    нексолько
                                    строчек, чтоб было понятно о чём новость/анонс/событие</div>
                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">
                                 <div class="date-event">25.05.2021</div>
                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>
                                 <div class="description__element-event">Можно предусмотреть краткое описание в
                                    нексолько
                                    строчек, чтоб было понятно о чём новость/анонс/событие</div>
                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">
                                 <div class="date-event">25.05.2021</div>
                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>
                                 <div class="description__element-event">Можно предусмотреть краткое описание в
                                    нексолько
                                    строчек, чтоб было понятно о чём новость/анонс/событие</div>
                              </div>
                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="arrows">
                     <div class="arrow-slider arow-next">next</div>
                     <div class="arrow-slider arow-prev">prev</div>
                  </div>
               </div>

               <!--  -------------- /Tabs  -------------- -->
         </section>


         <!-- -------------- Section join -------------- -->

         <section class="section section-join gray-section">
            <div class="_container">
               <div class="section__header__vertical">
                  <h2 class="section-title section-title__join">Вступи в Опору России!</h2>
                  <h3 class="section-description description__join">Развивай свой бизнес,
                     получай поддержку и защиту,
                     пользуйся картой предпринимателя!</h3>
               </div>


               <div class="section-join__features">
                  <div class="features__item__column">
                     <div class="features__item__number">1</div>
                     <div class="features__item__img">
                        <img src="<?php echo get_template_directory_uri();?>/assets/images/home-page/join-opora/Join.png" alt="Вступай в Опору России">
                     </div>
                     <div class="features__item__title">Вступай в "Опору России"</div>
                     <div class="features__item__description">Заполни онлайн-форму, внеси взнос получи Карту
                        предпринимателя.</div>
                  </div>
                  <div class="features__item__column">
                     <div class="features__item__number">2</div>
                     <div class="features__item__img">
                        <img src="<?php echo get_template_directory_uri();?>/assets/images/home-page/join-opora/Buisness.png" alt="Развивай Бизнес">
                     </div>
                     <div class="features__item__title">Развивай Бизнес</div>
                     <div class="features__item__description">Обращайся в комитеты, получай поддержку для своего
                        бизнеса.
                     </div>
                  </div>
                  <div class="features__item__column">
                     <div class="features__item__number">3</div>
                     <div class="features__item__img">
                        <img src="<?php echo get_template_directory_uri();?>/assets/images/home-page/join-opora/Defence.png" alt="Получай Защиту">
                     </div>
                     <div class="features__item__title">Получай Защиту</div>
                     <div class="features__item__description">Получай юридическую защиту, консультации экспертов.</div>
                  </div>
                  <div class="features__item__column">
                     <div class="features__item__number">4</div>
                     <div class="features__item__img">
                        <img src="<?php echo get_template_directory_uri();?>/assets/images/home-page/join-opora/Lawmaking.png" alt="Участвуй в Законотворчестве">
                     </div>
                     <div class="features__item__title">Участвуй в Законотворчестве</div>
                     <div class="features__item__description">Подавай свои инициативы, будь в диалоге с обществом и
                        властью.</div>
                  </div>
               </div>


               <div class="section-join__buttons">
                  <a href="#" class="btn section-join__btn-join">Вступить в Опору России</a>
                  <a href="#" class="btn section-join__btn-pay">Внести членский взнос</a>
               </div>
               <div class="section-join__warning">Членом организации может стать любой гражданин Российской Федерации,
                  достигший 18 лет, а также юридические лица – общественные объединения, разделяющие цели и задачи
                  организации и принимающие ее Устав. Членский взнос составляет 5000 рублей (срок действия 1 год).
               </div>

            </div>
         </section>

         <!-- -------------- /Section join -------------- -->


         <!-- -------------- Section action -------------- -->
         <section class="section section-action">
            <div class="_container">

               <div class="section__header">
                  <div class="section__wrapper__header">
                     <h2 class="section-title">Действуй!</h2>
                     <h3 class="section-description">Прояви свой предпринимательский потенциал,
                        активность и гражданскую позицию, преобрази свой город, страну, Планету, сделай Мир лучше!</h3>
                  </div>
                  <a href="#" class="btn section-join__btn-pay">Встпупить в опору России!</a>
               </div>

               <div class="services">
                  <div class="services__columns">
                     <div class="services__items">
                        <div class="services__item__img">
                           <img src="<?php echo get_template_directory_uri();?>/assets/images/home-page/active/my-project.png" alt="Реализуй свой проект !">
                        </div>

                        <div class="services__item__info">
                           <div class="services__item__info__title">Реализуй свой проект !</div>
                           <div class="services__item__info__description">Управляй своим бизнес-проектом, привлекай
                              единомышленников и партнеров, воплощай мечту!</div>
                           <a href="#" class="services__item__info__link">Положение об управлении проектами ></a>
                        </div>

                     </div>
                     <div class="services__items">
                        <div class="services__item__img">
                           <img src="<?php echo get_template_directory_uri();?>/assets/images/home-page/active/leader.png" alt="Стань лидером!">
                        </div>

                        <div class=" services__item__info">
                           <div class="services__item__info__title">Стань лидером!</div>
                           <div class="services__item__info__description">Создай местное отделение, привлекай активных,
                              творческих людей, развивай бизнес-проекты!</div>
                           <a href="#" class="services__item__info__link">Положение о территориальном отделении ></a>
                        </div>

                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- -------------- /Section action -------------- -->


         <!-- -------------- Section participation -------------- -->

         <section id="partners" class="sections sections-participation">
            <div class="_container">
               <div class="section__header">
                  <div class="section__wrapper__header">
                     <h2 class="section-title">Участвуй в успешных проектах!</h2>
                     <h3 class="section-description">Предлагай свои идеи, участвуй в проектах своими делами, энергией и
                        финансами, получай товары и услуги на выгодных условиях.</h3>
                  </div>

               </div>



               <!--  -------------- Tabs  -------------- -->

               <div class="tabs">
                  <ul class="tabs__list">
                     <li class="tabs__item"><button class="tabs__btn tabs__btn--active"
                           data-tabs-path="udm">Все</button></li>
                     <li class="tabs__item"><button class="tabs__btn" data-tabs-path="anons">Комитеты по культуре
                           бизнеса</button></li>
                     <li class="tabs__item"><button class="tabs__btn" data-tabs-path="comitets-culture">Комитет по
                           энергетике</button></li>
                     <li class="tabs__item"><button class="tabs__btn" data-tabs-path="comitets">Комитет по самозанятым
                           гражданам</button></li>


                  </ul>
                  <div class="tabs__content tabs__content--active" data-tabs-target="udm">
                     <div class="content">
                        <ul class="content__list">
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>
                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>
                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="tabs__content" data-tabs-target="anons">
                     <div class="content">
                        <ul class="content__list">
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">eecececec</div>

                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">eecececec</div>

                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">eecececec</div>

                              </div>
                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="tabs__content" data-tabs-target="comitets-culture">
                     <div class="content">
                        <ul class="content__list">
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>
                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="tabs__content" data-tabs-target="comitets">
                     <div class="content">
                        <ul class="content__list">
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/home-page/first-screen/bg__first-screen.png);">
                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>
                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="arrows">
                     <div class="arrow-slider arow-next">next</div>
                     <div class="arrow-slider arow-prev">prev</div>
                  </div>
               </div>

               <!--  -------------- /Tabs  -------------- -->
         </section>

         <!-- -------------- /Section participation -------------- -->


         <!-- -------------- Section partners -------------- -->
         <section class="section section-partners gray-section">
            <div class="_container">
               <div class="section__header">
                  <div class="section__wrapper__header">
                     <h2 class="section-title">Партнеры Удмуртского отделения</h2>
                     <h3 class="section-description">Мы открыты для сотрудничества и ценим каждую идею, предложенную
                        нашими партнерами.</h3>
                  </div>
               </div>
               <div class="partners__pictures">
                  <div class="partners__img">
                     <a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/images/home-page/partners/Качество жизни.png" alt="Качество жизни"></a>
                  </div>
                  <div class="partners__img">
                     <a href="#"> <img src="<?php echo get_template_directory_uri();?>/assets/images/home-page/partners/Миграционный Центр.png"
                           alt="Миграционный Центр"></a>
                  </div>
                  <div class="partners__img">
                     <a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/images/home-page/partners/Ресурсный центр.png" alt="Ресурсный центр"></a>
                  </div>
                  <div class="partners__img">
                     <a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/images/home-page/partners/Close connection.png" alt="Close connection"></a>
                  </div>
                  <div class="partners__img">
                     <a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/images/home-page/partners/Vortex.png" alt="Vortex"></a>
                  </div>
               </div>
            </div>
         </section>
         <!-- -------------- /Section partners -------------- -->

      </main>
<?php get_footer(); ?>