<?php 
/*
   Template Name: Комитеты
*/
?>

<?php get_header('dark'); ?>

      <main class="main">

      <section class="section section-comitets">
            <div class="_container">
               <div class="section__header">
                  <div class="section__wrapper__header">
                     <h2 class="section-title"><?php the_title(); ?></h2>
                  </div>

               </div>
               <div class="tabs">
                  <ul class="tabs__list">
                     <li class="tabs__item"><button class="tabs__btn tabs__btn--active"
                           data-tabs-path="udm">Все</button></li>
                     <li class="tabs__item"><button class="tabs__btn" data-tabs-path="anons">Комитеты по культуре
                           бизнеса</button></li>
                     <li class="tabs__item"><button class="tabs__btn" data-tabs-path="comitets-culture">Комитет по
                           энергетике</button></li>
                     <li class="tabs__item"><button class="tabs__btn" data-tabs-path="comitets">Комитет по самозанятым
                           гражданам</button></li>


                  </ul>
                  <div class="tabs__content tabs__content--active" data-tabs-target="udm">
                     <div class="content">
                        <ul class="grid-wrapper">
                          <?php
                              // параметры по умолчанию
                              $my_posts = get_posts( array(
                                 'numberposts' => -1,
                                 'category'    => 0,
                                 'orderby'     => 'date',
                                 'order'       => 'DESC',
                                 'include'     => array(),
                                 'exclude'     => array(),
                                 'meta_key'    => '',
                                 'meta_value'  =>'',
                                 'post_type'   => 'comitet',
                                 'suppress_filters' => true, // подавление работы фильтров изменения SQL запроса
                              ) );

                              foreach( $my_posts as $post ){
                                 setup_postdata( $post );

                                 ?>

                              <div class="comitet">
                                 <div class="comitet__logo">
                                    <?php 
                                       $photo = get_post_meta(get_the_ID(), 'comitet-image', true);
                                       $fullImg = pods_image_url($photo['ID'], 'large');

                                       echo '<img src="' . $fullImg . '" alt="Логтип комитета">'
                                    ?>
                                 </div>
                                 <p class="comitet_description">
                                 <?php echo get_post_meta(get_the_ID(), 'comitet-name', true) ?>
                                 </p>
                                 <a href="<?php echo get_template_directory_uri();?>/assets/images/comitets/comitet.svg" class="comitet__btn-more">Подробнее></a>
                              </div>
                                 
                                 <?php
                              }

                              wp_reset_postdata(); // сброс
                              ?>
                         
                      
                        </ul>
                     </div>
                  </div>
                  <div class="tabs__content" data-tabs-target="anons">
                     <div class="content">
                        <ul class="content__list">
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-color: blue;">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">eecececec</div>

                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-color: blue;">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">eecececec</div>

                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-color: blue;">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">eecececec</div>

                              </div>
                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="tabs__content" data-tabs-target="comitets-culture">
                     <div class="content">
                        <ul class="content__list">
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-color: blue;">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-color: blue;">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-color: blue;">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>
                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="tabs__content" data-tabs-target="comitets">
                     <div class="content">
                        <ul class="content__list">
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-color: blue;">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-color: blue;">

                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>

                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                           <li class="content__item">
                              <a href="#" class="content__link" style="background-color: blue;">
                              </a>
                              <div class="info-contetn__element-event">
                                 <div class="category__element-event">Новости</div>
                                 <div class="title__element-event">Бизнес-завтрак с Олегом Бекметьевым</div>

                              </div>
                              <a href="#" class="more__about-event">Смотреть полностью</a>
                           </li>
                        </ul>
                     </div>
                  </div>

               </div>
            </div>
         </section>

      </main>
<?php get_footer(); ?>