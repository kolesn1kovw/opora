

      <footer class="footer">
         <div class="_container">
            <div class="footer__header">
               <div class="footer__header__logo">
                  <a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/images/logo/big-logo.svg" alt="Опора России"></a>
               </div>
               <div class="footer__header__social-network">
                  <a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/images/social/facebook.svg" alt="facebook"></a>
                  <a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/images/social/vk.svg" alt="vk"></a>
                  <a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/images/social/youtube.svg" alt="youtube"></a>
                  <a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/images/social/telegram.svg" alt="telegram"></a>
               </div>
            </div>
            <nav class="footer__navigation">

               <ul class="footer__navigation__column">
                  <div class="navigation__column__name">Меню</div>
                  <li class="navigation__column__link"><a href="#">Миссия</a></li>
                  <li class="navigation__column__link"><a href="#">Комитеты</a></li>
                  <li class="navigation__column__link"><a href="#">Отделения</a></li>
                  <li class="navigation__column__link"><a href="#">Вступить</a></li>
               </ul>

               <ul class="footer__navigation__column">
                  <div class="navigation__column__name">Дела</div>
                  <li class="navigation__column__link"><a href="#">Проекты</a></li>
                  <li class="navigation__column__link"><a href="#">Инициативы</a></li>
                  <li class="navigation__column__link"><a href="#">Омбудсмен</a></li>
                  <li class="navigation__column__link"><a href="#">Документы</a></li>
               </ul>

               <ul class="footer__navigation__column">
                  <div class="navigation__column__name">Управление</div>
                  <li class="navigation__column__link"><a href="#">Председатель</a></li>
                  <li class="navigation__column__link"><a href="#">ЦА Опоры России</a></li>
                  <li class="navigation__column__link"><a href="#">Личный кабинет</a></li>
               </ul>

               <ul class="footer__navigation__column">
                  <div class="navigation__column__name">Контакты</div>
                  <li class="navigation__column__link"><a href="#">г.Ижевск, ул.Ленина, д.50</a></li>
                  <li class="navigation__column__link"><a href="tel:+73412658287">тел. +7 (3412) 65-82-87
                     </a></li>
                  <li class="navigation__column__link"><a
                        href="mailto:opora.udmurtia@gmail.com">opora.udmurtia@gmail.com</a></li>
               </ul>

            </nav>
            <div class="footer__footer">
               <span class="qualitylive">© 2021 qualitylive.su</span>
               <a href="#" class="privacy">Политика конфиденциальности</a>
            </div>
         </div>
      </footer>

      

   </div>

   <?php wp_footer(); ?>
</body>

</html>